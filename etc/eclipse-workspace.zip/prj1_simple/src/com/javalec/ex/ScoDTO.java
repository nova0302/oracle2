package com.javalec.ex;

public class ScoDTO {
	private String Id;
	private int Kor;
	private int Eng;
	private int Mat;
	private int His;

	public ScoDTO(String id, int k, int e, int m, int h){
		Id = id;
		Kor = k;
		Eng = e;
		Mat = m;
		His = h;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		this.Id = id;
	}

	public int getKor() {
		return Kor;
	}

	public void setKor(int kor) {
		Kor = kor;
	}

	public int getEng() {
		return Eng;
	}

	public void setEng(int eng) {
		Eng = eng;
	}

	public int getMat() {
		return Mat;
	}

	public void setMat(int mat) {
		Mat = mat;
	}

	public int getHis() {
		return His;
	}

	public void setHis(int his) {
		His = his;
	}
	

}