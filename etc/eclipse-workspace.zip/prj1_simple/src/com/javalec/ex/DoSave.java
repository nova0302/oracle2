package com.javalec.ex;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.ScoDAO;

/**
 * Servlet implementation class DoSave
 */
@WebServlet("/DoSave")
public class DoSave extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 String Id;
     int Kor, Mat, Eng, His;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoSave() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Id = request.getParameter("Id");
		Kor = Integer.parseInt(request.getParameter("Kor"));
		Mat = Integer.parseInt(request.getParameter("Mat"));
		Eng = Integer.parseInt(request.getParameter("Eng"));
		His = Integer.parseInt(request.getParameter("His"));
		//ScoDTO dto = new ScoDTO(Id, Kor, Mat, Eng, His);
		ScoDAO dao = new ScoDAO();
		dao.write(Id, Kor, Mat, Eng, His);
		response.sendRedirect("index.jsp?section=saveScore.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
