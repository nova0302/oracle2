package edu.smh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import edu.smh.dto.HelloDto;
import edu.smh.dto.SaleListDto;
import edu.smh.dto.WorldDto;

public class HelloWorldDao {

	DataSource dataSource;
	public HelloWorldDao() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public ArrayList<HelloDto> hList() {
		ArrayList<HelloDto> dtos = new ArrayList<HelloDto>();
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT name, id FROM student";
			ps = connection.prepareStatement(query);
			rs = ps.executeQuery();
			System.out.println("DAO:hList");
			while (rs.next()) {
				String name = rs.getString("name");
				String id = rs.getString("id");
				dtos.add(new HelloDto(name,id));
			
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			
		}finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return dtos;
	}
	public ArrayList<WorldDto> wList() {
		ArrayList<WorldDto> dtos = new ArrayList<WorldDto>();
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT name, tel FROM student";
			ps = connection.prepareStatement(query);
			rs = ps.executeQuery(query);
			System.out.println("DAO:hList");
			while (rs.next()) {
				String name = rs.getString("name");
				String tel = rs.getString("tel");
				dtos.add(new WorldDto(name,tel));
			
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			
		}finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return dtos;
	}
	
	public ArrayList<SaleListDto> sList() {
		ArrayList<SaleListDto> dtos = new ArrayList<SaleListDto>();
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT saleno, pcode, to_char(saledate, 'yyyy-mm-dd') saledate,"
					+ "scode, amount FROM tbl_salelist_01";
			ps = connection.prepareStatement(query);
			rs = ps.executeQuery(query);
			System.out.println("DAO:hList");
			while (rs.next()) {
				String saleno = rs.getString("saleno");
				String pcode = rs.getString("pcode");
				String saledate = rs.getString("saledate");
				String scode = rs.getString("scode");
				String amount = rs.getString("amount");

				dtos.add(new SaleListDto(saleno,pcode, saledate, scode, amount));
			
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			
		}finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return dtos;
	}	

}



