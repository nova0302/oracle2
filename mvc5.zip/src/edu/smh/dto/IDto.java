package edu.smh.dto;

public class IDto {

}
