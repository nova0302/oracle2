package com.javalec.ex.dto;

public class LBDto {
	int bCode;
	String name, type;
	
	public LBDto(int bCode, String name, String type) {
		// TODO Auto-generated constructor stub
		this.bCode = bCode;
		this.name = name;
		this.type = type;
	}
	

}
