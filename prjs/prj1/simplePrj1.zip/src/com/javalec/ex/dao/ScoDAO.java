package com.javalec.ex.dao;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.javalec.ex.dto.*;

public class ScoDAO {
	private String url = "jdbc:oracle:thin:@localhost:1521/xepdb1";
	private String uid = "scott";
	private String upw = "tiger";
	
	public ScoDAO() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (Exception e){
			e.printStackTrace();
		}		
	}
	
	public ArrayList<ScoDTO> scoreSelect(){
		ArrayList<ScoDTO> dtos = new ArrayList<ScoDTO>();
		Connection con=null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			con = DriverManager.getConnection(url, uid, upw);
			stmt =  con.createStatement();
			rs =  stmt.executeQuery("select * from score_tbl");
			
			while(rs.next()) {
				
				String id = rs.getString("ID");
				int Kor = rs.getInt("KOREAN");
				int Eng = rs.getInt("ENGLISH");
				int Mat = rs.getInt("MATH");
				int His = rs.getInt("HISTORY");
				ScoDTO dto = new ScoDTO(id, Kor, Eng, Mat, His);
				dtos.add(dto);
			}							
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null)stmt.close();
				if(con != null)con.close();				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	 
	public void write(String Id, int Kor, int Eng, int Mat, int His) {
		// TODO Auto-generated method stub
		
		Connection con = null;
		PreparedStatement pStmt = null;
		
		try {
			con = DriverManager.getConnection(url, uid, upw);
			String query = "insert into score_tbl values (?, ?, ?, ?, ? )";
			pStmt = con.prepareStatement(query);
			pStmt.setString(1, Id);
			pStmt.setInt(2, Kor);
			pStmt.setInt(3, Eng);
			pStmt.setInt(4, Mat);
			pStmt.setInt(5, His);
			int rn = pStmt.executeUpdate();
			con.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(pStmt != null) pStmt.close();
				if(con != null) con.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
	}
		
	
}
