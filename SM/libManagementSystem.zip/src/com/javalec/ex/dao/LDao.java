package com.javalec.ex.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.ResultSet;
//import java.util.ArrayList;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.javalec.ex.dto.LBDto;
import com.javalec.ex.dto.LDto;
import com.javalec.ex.dto.LMDto;

public class LDao {
	DataSource dataSource;
	public LDao() {
		// TODO Auto-generated constructor stub
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public String bRegister(String bName, String type) {
		// TODO Auto-generated method stub
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String isSuccess = "0";
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "SELECT COUNT(name) n FROM tb_book WHERE name=? and type=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, bName);
			preparedStatement.setString(2, type);
			rs = preparedStatement.executeQuery();
			rs.next();
			isSuccess = rs.getString("n");
			if(isSuccess.equals("0")) {
				preparedStatement.close();
				query = "insert into tb_book values (seq_book.NEXTVAL, ?, ?)";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, bName);
				preparedStatement.setString(2, type);
				preparedStatement.executeUpdate();
			}	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return isSuccess; // 0 : success, 1 : fail
	}
	public String mRegister(String mName, String tel) {
		// TODO Auto-generated method stub
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String isSuccess = "0";
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "SELECT COUNT(name) n FROM tb_member WHERE name=? and tel=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, mName);
			preparedStatement.setString(2, tel);
			rs = preparedStatement.executeQuery();
			rs.next();
			isSuccess = rs.getString("n");
			if(isSuccess.equals("0")) {
				preparedStatement.close();
				query = "insert into tb_member values (seq_member.NEXTVAL, ?, ?)";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, mName);
				preparedStatement.setString(2, tel);
				preparedStatement.executeUpdate();
			}	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return isSuccess; // 0 : success, 1 : fail
	}

	public ArrayList<LMDto> mList(){
		ArrayList<LMDto> dtos = new ArrayList<LMDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		
		/*DBCP�κ��� Connection�� ���, �����ͺ��̽��� ���õ� �ʿ��� �۾�� �����Ѵ�.*/
		try {
			connection = dataSource.getConnection();
			
			String query = "SELECT * FROM vmList";
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			System.out.println("DAO");
			while (rs.next()) {
				String mName = rs.getString("n");
				String mTel = rs.getString("t");	
				int nRent = rs.getInt("nrent");
				LMDto dto = new LMDto(mName, mTel, nRent);
				System.out.printf("name: %15s, tel: %s, nRent:%d%n", mName,  mTel, nRent );
				dtos.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return dtos;
	}

	public ArrayList<LDto> bStatus(int sel){
		ArrayList<LDto> dtos = new ArrayList<LDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String query = null;
		if(0 == sel)  		query = "SELECT * FROM vbStatus";
		else if(1 == sel) 	query = "SELECT * FROM vbStatusB";
		else 				query = "SELECT * FROM vbStatusR";
		/*DBCP�κ��� Connection�� ���, �����ͺ��̽��� ���õ� �ʿ��� �۾�� �����Ѵ�.*/
		try {
			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				String nRent = rs.getString("nRent");
				String bName = rs.getString("å�̸�");
				String bType = rs.getString("å�帣");
				String isRented = rs.getString("�뿩����");
				String rDate = rs.getString("�뿩��¥");
				String mName = rs.getString("�뿩ȸ��");
				String Rent = rs.getString("�ݳ�/�뿩");
				System.out.printf("bName: %10s, Jarn: %10s, rDate: %10s, mName: %10s%n", 
						bName, bType, rDate, mName);
				LDto dto = new LDto(nRent,bName, bType, isRented, rDate, mName,Rent);
				dtos.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return dtos;
	}	

	public ArrayList<LBDto> bList(){
		ArrayList<LBDto> dtos = new ArrayList<LBDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		
		/*DBCP�κ��� Connection�� ���, �����ͺ��̽��� ���õ� �ʿ��� �۾�� �����Ѵ�.*/
		try {
			connection = dataSource.getConnection();
			
			String query = "SELECT name n, type t FROM tb_book";
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			System.out.println("DAO");
			while (rs.next()) {
				String mBName = rs.getString("n");
				String mType = rs.getString("t");				
				LBDto dto = new LBDto(mBName, mType, 0);
				//System.out.printf("name: %15s, tel: %s%n", mName,  mTel);
				dtos.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return dtos;
	}
	
	public ArrayList<LDto> bSearch(String bName, String bType, String mName){
		ArrayList<LDto> dtos = new ArrayList<LDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		
		/*DBCP�κ��� Connection�� ���, �����ͺ��̽��� ���õ� �ʿ��� �۾��� �����Ѵ�.*/
		try {
			connection = dataSource.getConnection();
			String query = "SELECT * FROM vbStatus v WHERE ";
			if(bName != null && bName != "") query += " v.\"å�̸�\"=" + "'"+ bName+ "'";
			if(bType != null && bType != "") query += " v.\"å�帣\"=" + "'"+ bType+ "'";
			if(mName != null && mName != "") query += " v.\"�뿩ȸ��\"=" + "'"+ mName+ "'";
			System.out.println(query);
			preparedStatement = connection.prepareStatement(query);		
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				String nRent = rs.getString("nRent");
				String bbName = rs.getString("å�̸�");
				String bbType = rs.getString("å�帣");
				String isRented = rs.getString("�뿩����");
				String rDate = rs.getString("�뿩��¥");
				String mmName = rs.getString("�뿩ȸ��");
				String Rent = rs.getString("�ݳ�/�뿩");
				System.out.printf("nRent: %s, bName: %10s, Jarn: %10s, isRented: %s, rDate: %10s, mName: %10s, Rent: %s%n", 
						nRent, bbName, bbType, isRented, rDate, mmName, Rent);
				LDto dto = new LDto(nRent, bbName, bbType, isRented, rDate, mmName, Rent);
				dtos.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return dtos;
	}

	public void bReturnTheBook(String nRent) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "DELETE FROM tb_rent WHERE nRent='"+nRent+"'";
			preparedStatement = connection.prepareStatement(query);
			//preparedStatement.setString(1, nRent);	
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}