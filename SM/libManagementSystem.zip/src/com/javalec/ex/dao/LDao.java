package com.javalec.ex.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.ResultSet;
//import java.util.ArrayList;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.javalec.ex.dto.LBDto;
import com.javalec.ex.dto.LDto;
import com.javalec.ex.dto.LMDto;

public class LDao {
	DataSource dataSource;
	public LDao() {
		// TODO Auto-generated constructor stub
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public int bRegister(String bName, String type) {
		// TODO Auto-generated method stub
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int isSuccess = 0;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "SELECT COUNT(name) n FROM tb_book WHERE name=?, type=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, bName);
			preparedStatement.setString(2, type);
			rs = preparedStatement.executeQuery();
			rs.next();
			isSuccess = rs.getInt("n");
			if(isSuccess == 0) {
				preparedStatement.close();
				query = "insert into tb_book values (seq_book.NEXTVAL, ?, ?)";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, bName);
				preparedStatement.setString(2, type);
				preparedStatement.executeUpdate();
			}	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return isSuccess; // 0 : success, 1 : fail
	}
	public void mRegister(String mName, String phone) {
		// TODO Auto-generated method stub
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "insert into tb_member values (seq_member.NEXTVAL, ?, ?)";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, mName);
			preparedStatement.setString(2, phone);
			
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	}

	public ArrayList<LMDto> mList(){
		ArrayList<LMDto> dtos = new ArrayList<LMDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		
		/*DBCP�κ��� Connection�� ���, �����ͺ��̽��� ���õ� �ʿ��� �۾�� �����Ѵ�.*/
		try {
			connection = dataSource.getConnection();
			
			String query = "SELECT * FROM vmList";
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			System.out.println("DAO");
			while (rs.next()) {
				String mName = rs.getString("n");
				String mTel = rs.getString("t");	
				int nRent = rs.getInt("nrent");
				LMDto dto = new LMDto(mName, mTel, nRent);
				System.out.printf("name: %15s, tel: %s, nRent:%d%n", mName,  mTel, nRent );
				dtos.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return dtos;
	}

	public ArrayList<LDto> bStatus(int sel){
		ArrayList<LDto> dtos = new ArrayList<LDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String query = null;
		if(0 == sel)  		query = "SELECT * FROM vbStatus";
		else if(1 == sel) 	query = "SELECT * FROM vbStatusB";
		else 				query = "SELECT * FROM vbStatusR";
		/*DBCP�κ��� Connection�� ���, �����ͺ��̽��� ���õ� �ʿ��� �۾�� �����Ѵ�.*/
		try {
			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				String bName = rs.getString("å�̸�");
				String bType = rs.getString("å�帣");
				String rDate = rs.getString("�뿩��¥");
				String mName = rs.getString("�뿩ȸ��");
				System.out.printf("bName: %10s, Jarn: %10s, rDate: %10s, mName: %10s%n", 
						bName, bType, rDate, mName);
				LDto dto = new LDto(bName, bType, rDate, mName);
				dtos.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return dtos;
	}	

	public ArrayList<LBDto> bList(){
		ArrayList<LBDto> dtos = new ArrayList<LBDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		
		/*DBCP�κ��� Connection�� ���, �����ͺ��̽��� ���õ� �ʿ��� �۾�� �����Ѵ�.*/
		try {
			connection = dataSource.getConnection();
			
			String query = "SELECT name n, type t FROM tb_book";
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			System.out.println("DAO");
			while (rs.next()) {
				String mBName = rs.getString("n");
				String mType = rs.getString("t");				
				LBDto dto = new LBDto(mBName, mType, 0);
				//System.out.printf("name: %15s, tel: %s%n", mName,  mTel);
				dtos.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return dtos;
	}
}