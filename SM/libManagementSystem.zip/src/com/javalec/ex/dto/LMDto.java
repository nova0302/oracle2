package com.javalec.ex.dto;

public class LMDto {

	String mMCode, mMName, mPhone;
		
	public LMDto() {}
	public LMDto(String mMCode, String mName, String mPhone) {
		this.mMCode = mMCode;
		this.mMName = mName;
		this.mPhone = mPhone;	
	}
	
	public String getmMCode() {
		return mMCode;
	}
	public void setmMCode(String mMCode) {
		this.mMCode = mMCode;
	}
	public String getmMName() {
		return mMName;
	}
	public void setmMName(String mMName) {
		this.mMName = mMName;
	}
	public String getmPhone() {
		return mPhone;
	}
	public void setmPhone(String mPhone) {
		this.mPhone = mPhone;
	}	
}
