package com.javalec.ex.dto;

public class LBDto {
	String mBname, mType;
	int mNumOfRent;
	public LBDto() {}
	public LBDto(String mBname, String mType, int mNumOfRent) {
		super();
		this.mBname = mBname;
		this.mType = mType;
		this.mNumOfRent = mNumOfRent;
	}
	public String getmBname() {
		return mBname;
	}
	public void setmBname(String mBname) {
		this.mBname = mBname;
	}
	public String getmType() {
		return mType;
	}
	public void setmType(String mType) {
		this.mType = mType;
	}
	public int getmNumOfRent() {
		return mNumOfRent;
	}
	public void setmNumOfRent(int mNumOfRent) {
		this.mNumOfRent = mNumOfRent;
	}
	
	
	
}
