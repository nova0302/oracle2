package com.javalec.ex.frontcontroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.command.LBListCommand;
import com.javalec.ex.command.LCommand;
import com.javalec.ex.command.LMListCommand;
import com.javalec.ex.command.LMRegisterCommand;
import com.javalec.ex.command.LRegisterCommand;
import com.javalec.ex.command.LStatusCommand;
import com.javalec.ex.misc.LEOrder;


/**
 * Servlet implementation class LFrontController
 */
@WebServlet("*.do")
public class LFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LFrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}
	
	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("actionDo");		
		request.setCharacterEncoding("utf-8");
		
		String viewPage = null;
		LCommand command = null;
		
		String uri = request.getRequestURI();	
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		
		if(com.equals("/bRegView.do")){ /*   �������   */		
			//viewPage = "bRegView.jsp";
			request.setAttribute("section", "bRegView.jsp");
		}else if(com.equals("/bReg.do")){			
			command = new LRegisterCommand();
			command.execute(request, response);
			//viewPage = "bRegView.jsp";
			request.setAttribute("section", "bRegView.jsp");
		}else if(com.equals("/mRegView.do")){/*   ȸ�����   */			
			//viewPage = "mRegView.jsp";	
			request.setAttribute("section", "mRegView.jsp");
		}else if(com.equals("/mReg.do")){		
			command = new LMRegisterCommand();
			command.execute(request, response);
			//viewPage = "mRegView.jsp";	
			request.setAttribute("section", "mRegView.jsp");
		}else if(com.equals("/statView.do")){/*  �� �� */	
			command = new LBListCommand();
			command.execute(request, response);
			//viewPage = "statView.jsp";
			request.setAttribute("section", "statView.jsp");	
		}else if(com.equals("/mListView.do")){/*   ȸ����Ȳ */		
			command = new LMListCommand();
			command.execute(request, response);
			//viewPage = "mListView.jsp";	
			request.setAttribute("section", "mListView.jsp");
		}else if(com.equals("/bStatusView.do")){/*   ������Ȳ */
			command = new LStatusCommand(0);
			command.execute(request, response);
			//viewPage = "bStatusView.jsp";	
			request.setAttribute("section", "bStatusView.jsp");
		}else if(com.equals("/bStatusViewB.do")){/*   ������Ȳ */		
			command = new LStatusCommand(1);
			command.execute(request, response);
			//viewPage = "bStatusView.jsp";	
			request.setAttribute("section", "bStatusView.jsp");
		}else if(com.equals("/bStatusViewR.do")){/*   ������Ȳ */		
			command = new LStatusCommand(2);
			command.execute(request, response);
			//viewPage = "bStatusView.jsp";
			request.setAttribute("section", "bStatusView.jsp");
		}		
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);	
	}

}