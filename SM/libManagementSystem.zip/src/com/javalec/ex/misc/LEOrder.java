package com.javalec.ex.misc;

public enum LEOrder {
  eByBook, eByMember
}
