package com.javalec.ex.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.dao.LDao;

public class LMRegisterCommand implements LCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String isSuccess= "0";
		String mName = request.getParameter("mName");
		String tel = request.getParameter("tel");
		System.out.println("mName:" + mName +"tel" + tel);
		LDao dao = new LDao();
		isSuccess = dao.mRegister(mName, tel);	
		// 0 : success, 1 : fail
		request.setAttribute("isSuccess", isSuccess);
	}

}
