package com.javalec.ex.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.dao.LDao;

public class LRegisterCommand implements LCommand{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		int isSuccess= 0;
		String bName = request.getParameter("bName");
		String type = request.getParameter("type");
		System.out.println("bName:" + bName +"type" + type);
		LDao dao = new LDao();
		isSuccess = dao.bRegister(bName, type);	
		// 0 : success, 1 : fail
		request.setAttribute("isSuccess", isSuccess);
	}
}