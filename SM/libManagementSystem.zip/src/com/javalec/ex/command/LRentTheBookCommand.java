package com.javalec.ex.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.dao.LDao;

public class LRentTheBookCommand implements LCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String pCode = request.getParameter("pCode");
		String mCode = request.getParameter("mCode");
		LDao dao = new LDao();
		dao.rentTheBook(pCode, mCode);
	}

}
