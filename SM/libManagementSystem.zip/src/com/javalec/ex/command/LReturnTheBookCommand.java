package com.javalec.ex.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.dao.LDao;

public class LReturnTheBookCommand implements LCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String nRent = request.getParameter("nRent");
		LDao dao = new LDao();
		dao.bReturnTheBook(nRent);
	}
}
