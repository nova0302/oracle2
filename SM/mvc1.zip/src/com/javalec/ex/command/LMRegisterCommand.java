package com.javalec.ex.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.dao.LDao;

public class LMRegisterCommand implements LCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String mName = request.getParameter("mName");
		String phone = request.getParameter("phone");
		System.out.println("mName:" + mName +"phone" + phone);
		LDao dao = new LDao();
		dao.mRegister(mName, phone);	
	}

}
