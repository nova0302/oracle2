package edu.sm.ex.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import edu.sm.ex.dto.CSaleListByProductDto;

public class CDao {
	DataSource dataSource;
	public CDao() {
		// TODO Auto-generated constructor stub
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public ArrayList<CSaleListByProductDto> getCSaleListByProductDto(){
		
		ArrayList<CSaleListByProductDto> dtos = new ArrayList<CSaleListByProductDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		
		/*DBCP�κ��� Connection�� ���, �����ͺ��̽��� ���õ� �ʿ��� �۾�� �����Ѵ�.*/
		try {
			connection = dataSource.getConnection();
			
			String query = "SELECT * FROM vp1";
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			System.out.println("DAO");
			while (rs.next()) {
				String pcode = rs.getString("pcode");
				String name = rs.getString("name");
				String total = rs.getString("total");
				CSaleListByProductDto dto = new CSaleListByProductDto(pcode, name, total);
				System.out.printf("pcode: %15s, name: %s, total: %s%n", name,  pcode, total);
				dtos.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
		return dtos;
	}

}
