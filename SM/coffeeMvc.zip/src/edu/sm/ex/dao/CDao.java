package edu.sm.ex.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import edu.sm.ex.dto.CSaleListByProductDto;
import edu.sm.ex.dto.CSaleListByShopDto;
import edu.sm.ex.dto.CSaleListDto;

public class CDao {
	DataSource dataSource;
	public CDao() {
		// TODO Auto-generated constructor stub
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public ArrayList<CSaleListByProductDto> getCSaleListByProductDto(){
		
		ArrayList<CSaleListByProductDto> dtos = new ArrayList<CSaleListByProductDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		
		/*DBCP�κ��� Connection�� ���, �����ͺ��̽��� ���õ� �ʿ��� �۾�� �����Ѵ�.*/
		try {
			connection = dataSource.getConnection();
			
			String query = "SELECT * FROM vp1";
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			System.out.println("DAO");
			while (rs.next()) {
				String pcode = rs.getString("pcode");
				String name = rs.getString("name");
				String total = rs.getString("total");
				CSaleListByProductDto dto = new CSaleListByProductDto(pcode, name, total);
				System.out.printf("pcode: %15s, name: %s, total: %s%n", name,  pcode, total);
				dtos.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}	
		return dtos;
	}
	public ArrayList<CSaleListByShopDto> getCSaleListByShopDto(){
		
		ArrayList<CSaleListByShopDto> dtos = new ArrayList<CSaleListByShopDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		
		/*DBCP�κ��� Connection�� ���, �����ͺ��̽��� ���õ� �ʿ��� �۾�� �����Ѵ�.*/
		try {
			connection = dataSource.getConnection();
			
			String query = "SELECT * FROM vs1";
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			System.out.println("DAO");
			while (rs.next()) {
				String pcode = rs.getString("scode");
				String name = rs.getString("sname");
				String total = rs.getString("total");
				CSaleListByShopDto dto = new CSaleListByShopDto(pcode, name, total);
				System.out.printf("pcode: %15s, name: %s, total: %s%n", name,  pcode, total);
				dtos.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}	
		return dtos;
	}
	public ArrayList<CSaleListDto> getCSaleListDto(){
		
		ArrayList<CSaleListDto> dtos = new ArrayList<CSaleListDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		
		/*DBCP�κ��� Connection�� ���, �����ͺ��̽��� ���õ� �ʿ��� �۾�� �����Ѵ�.*/
		try {
			connection = dataSource.getConnection();
			
			String query = "SELECT * FROM v_sale";
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			System.out.println("DAO");
			while (rs.next()) {
				String saleno = rs.getString("saleno");
				String pcode = rs.getString("pcode");
				String saledate = rs.getString("saledate");
				String scode = rs.getString("scode");
				String name = rs.getString("name");
				String amount = rs.getString("amount");
				String subTotal = rs.getString("sub_total");
		
				CSaleListDto dto = new CSaleListDto(saleno, pcode, saledate, scode, name, amount, subTotal);
				//System.out.printf("pcode: %15s, name: %s, total: %s%n", name,  pcode, total);
				dtos.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}	
		return dtos;
	}
}
