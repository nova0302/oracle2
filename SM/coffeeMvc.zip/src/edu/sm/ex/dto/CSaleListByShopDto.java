package edu.sm.ex.dto;

public class CSaleListByShopDto {
	String mSCode, mSName, mTotal;

	public CSaleListByShopDto(String mSCode, String mSName, String mTotal) {
		super();
		this.mSCode = mSCode;
		this.mSName = mSName;
		this.mTotal = mTotal;
	}

	public String getmSCode() {
		return mSCode;
	}

	public void setmSCode(String mSCode) {
		this.mSCode = mSCode;
	}

	public String getmSName() {
		return mSName;
	}

	public void setmSName(String mSName) {
		this.mSName = mSName;
	}

	public String getmTotal() {
		return mTotal;
	}

	public void setmTotal(String mTotal) {
		this.mTotal = mTotal;
	}

}
