package edu.sm.ex.dto;

public class CSaleListByProductDto {
	String mPCode, mPName, mTotal;

	public CSaleListByProductDto(String mPCode, String mPName, String mTotal) {
		super();
		this.mPCode = mPCode;
		this.mPName = mPName;
		this.mTotal = mTotal;
	}

	public String getmPCode() {
		return mPCode;
	}

	public void setmPCode(String mPCode) {
		this.mPCode = mPCode;
	}

	public String getmPName() {
		return mPName;
	}

	public void setmPName(String mPName) {
		this.mPName = mPName;
	}

	public String getmTotal() {
		return mTotal;
	}

	public void setmTotal(String mTotal) {
		this.mTotal = mTotal;
	}
	
}
