package edu.sm.ex.dto;

public class CSaleListDto {
	String mSaleno, mPCode, mDate, mSCode, mPName, mAmount, mTotal;

	
	public CSaleListDto() {}
	public CSaleListDto(String mSaleno, String mPCode, String mDate, String mSCode, String mPName, String mAmount,
			String mTotal) {
		super();
		this.mSaleno = mSaleno;
		this.mPCode = mPCode;
		this.mDate = mDate;
		this.mSCode = mSCode;
		this.mPName = mPName;
		this.mAmount = mAmount;
		this.mTotal = mTotal;
	}
	public String getmSaleno() {
		return mSaleno;
	}

	public void setmSaleno(String mSaleno) {
		this.mSaleno = mSaleno;
	}

	public String getmPCode() {
		return mPCode;
	}

	public void setmPCode(String mPCode) {
		this.mPCode = mPCode;
	}

	public String getmDate() {
		return mDate;
	}

	public void setmDate(String mDate) {
		this.mDate = mDate;
	}

	public String getmSCode() {
		return mSCode;
	}

	public void setmSCode(String mSCode) {
		this.mSCode = mSCode;
	}

	public String getmPName() {
		return mPName;
	}

	public void setmPName(String mPName) {
		this.mPName = mPName;
	}

	public String getmAmount() {
		return mAmount;
	}

	public void setmAmount(String mAmount) {
		this.mAmount = mAmount;
	}

	public String getmTotal() {
		return mTotal;
	}

	public void setmTotal(String mTotal) {
		this.mTotal = mTotal;
	}
}
