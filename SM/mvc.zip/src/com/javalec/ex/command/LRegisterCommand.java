package com.javalec.ex.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.dao.LDao;

public class LRegisterCommand implements LCommand{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String bName = request.getParameter("bName");
		String type = request.getParameter("type");
		System.out.println("bName:" + bName +"type" + type);
		LDao dao = new LDao();
		dao.bRegister(bName, type);		
	}
}
